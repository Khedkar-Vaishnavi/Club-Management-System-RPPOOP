from django.db import models

# Create your models here.
class reg(models.Model):
    name = models.CharField(max_length=120, default='')
    email = models.CharField(max_length=120, default='')
    phone = models.CharField(max_length=12, default='')
    event = models.CharField(max_length=20, default='')
    date = models.DateField()

    def __str__(self):
        return self.name

class reg1(models.Model):
    name1 = models.CharField(max_length=120, default='')
    email1 = models.CharField(max_length=120, default='')
    phone1 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name1

class reg2(models.Model):
    name2 = models.CharField(max_length=120, default='')
    email2 = models.CharField(max_length=120, default='')
    phone2 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name2

class reg3(models.Model):
    name3 = models.CharField(max_length=120, default='')
    email3 = models.CharField(max_length=120, default='')
    phone3 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name3

class reg4(models.Model):
    name4 = models.CharField(max_length=120, default='')
    email4 = models.CharField(max_length=120, default='')
    phone4 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name4

class reg5(models.Model):
    name5 = models.CharField(max_length=120, default='')
    email5 = models.CharField(max_length=120, default='')
    phone5 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name5

class reg6(models.Model):
    name6 = models.CharField(max_length=120, default='')
    email6 = models.CharField(max_length=120, default='')
    phone6 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name6

class reg7(models.Model):
    name7 = models.CharField(max_length=120, default='')
    email7 = models.CharField(max_length=120, default='')
    phone7 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name7

class reg8(models.Model):
    name8 = models.CharField(max_length=120, default='')
    email8 = models.CharField(max_length=120, default='')
    phone8 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name8

class reg9(models.Model):
    name9 = models.CharField(max_length=120, default='')
    email9 = models.CharField(max_length=120, default='')
    phone9 = models.CharField(max_length=12, default='')
    
    date = models.DateField()

    def __str__(self):
        return self.name9