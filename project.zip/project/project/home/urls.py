from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    path('', views.index, name='home'),
    path('about', views.about, name='about'),
    path('contacts', views.contacts, name='contacts'),
    path('club1', views.club1, name='club1'),
    path('club2', views.club2, name='club2'),
    path('club3', views.club3, name='club3'),
    path('club4', views.club4, name='club4'),
    path('club5', views.club5, name='club5'),
    path('club6', views.club6, name='club6'),
    path('events1', views.events1, name='club1_events1'),
    path('events1_2', views.events1_2, name='club1_events1_2'),
    path('events2', views.events2, name='club2_events2'),
    path('events2_1', views.events2_1, name='club2_events2_1'),
    path('events3', views.events3, name='club3_events'),
    path('events3_1', views.events3_1, name='club3_events3_1'),
    path('events4', views.events4, name='club4_events'),
    path('events4_1', views.events4_1, name='club4_events4_1'),
    path('events5', views.events5, name='club5_events'),
    path('events6', views.events6, name='club6_events'),
    path('register1', views.register1, name='register1'),
    path('register1_2', views.register1_2, name='register1_2'),
    path('register2', views.register2, name='register2'),
    path('register2_1', views.register2_1, name='register2_1'),
    path('register3', views.register3, name='register3'),
    path('register3_1', views.register3_1, name='register3_1'),
    path('register4', views.register4, name='register4'),
    path('register4_1', views.register4_1, name='register4_1'),
    path('register5', views.register5, name='register5'),
    path('register6', views.register6, name='register6')

]