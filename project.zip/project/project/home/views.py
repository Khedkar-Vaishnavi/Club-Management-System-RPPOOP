from atexit import register
from django.shortcuts import render, HttpResponse
from datetime import datetime
from home.models import reg
from home.models import reg1, reg2, reg3, reg4, reg5, reg6, reg7, reg8, reg9

# Create your views here.
def index(request):
    #return HttpResponse('This is index page')
    return render(request,'index.html')

def about(request):
    return HttpResponse('This is about page')

def contacts(request):
    return render(request, 'contact.html')

def club1(request):
    return render(request, 'club1.html')

def club2(request):
    return render(request, 'club2.html')

def club3(request):
    return render(request, 'club3.html')

def club4(request):
    return render(request, 'club4.html')

def club5(request):
    return render(request, 'club5.html')

def club6(request):
    return render(request, 'club6.html')

def events1(request):
    return render(request, 'events1.html')

def events1_2(request):
    return render(request, 'events1_2.html')

def events2(request):
    return render(request, 'events2.html')

def events2_1(request):
    return render(request, 'events2_1.html')

def events3(request):
    return render(request, 'events3.html')

def events3_1(request):
    return render(request, 'events3_1.html')

def events4(request):
    return render(request, 'events4.html')

def events4_1(request):
    return render(request, 'events4_1.html')

def events5(request):
    return render(request, 'events5.html')

def events6(request):
    return render(request, 'events6.html')

def register1(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        event = request.POST.get('event')
        register1 = reg(name=name, email=email, phone=phone, event=event,date=datetime.today())
        register1.save()

    return render(request, 'register1.html')

def register1_2(request):
    if request.method == "POST":
        name1 = request.POST.get('name1')
        email1 = request.POST.get('email1')
        phone1 = request.POST.get('phone1')
        
        register2 = reg1(name1=name1, email1=email1, phone1=phone1,date=datetime.today())
        register2.save()

    return render(request, 'register1_2.html')

def register2(request):
    if request.method == "POST":
        name2 = request.POST.get('name2')
        email2 = request.POST.get('email2')
        phone2 = request.POST.get('phone2')
        
        register3 = reg2(name2=name2, email2=email2, phone2=phone2,date=datetime.today())
        register3.save()

    return render(request, 'register2.html')

def register2_1(request):
    if request.method == "POST":
        name3 = request.POST.get('name3')
        email3 = request.POST.get('email3')
        phone3 = request.POST.get('phone3')
        
        register4 = reg3(name3=name3, email3=email3, phone3=phone3,date=datetime.today())
        register4.save()
    return render(request, 'register2_1.html')

def register3(request):
    if request.method == "POST":
        name4 = request.POST.get('name4')
        email4 = request.POST.get('email4')
        phone4 = request.POST.get('phone4')
        
        register5 = reg4(name4=name4, email4=email4, phone4=phone4,date=datetime.today())
        register5.save()
    return render(request, 'register3.html')

def register3_1(request):
    if request.method == "POST":
        name5 = request.POST.get('name5')
        email5 = request.POST.get('email5')
        phone5 = request.POST.get('phone5')
        
        register6 = reg5(name5=name5, email5=email5, phone5=phone5,date=datetime.today())
        register6.save()
    return render(request, 'register3_1.html')

def register4(request):
    if request.method == "POST":
        name6 = request.POST.get('name6')
        email6 = request.POST.get('email6')
        phone6 = request.POST.get('phone6')
        
        register7 = reg6(name6=name6, email6=email6, phone6=phone6,date=datetime.today())
        register7.save()
    return render(request, 'register4.html')

def register4_1(request):
    if request.method == "POST":
        name7 = request.POST.get('name7')
        email7 = request.POST.get('email7')
        phone7 = request.POST.get('phone7')
        
        register8 = reg7(name7=name7, email7=email7, phone7=phone7,date=datetime.today())
        register8.save()
    return render(request, 'register4_1.html')

def register5(request):
    if request.method == "POST":
        name8 = request.POST.get('name8')
        email8 = request.POST.get('email8')
        phone8 = request.POST.get('phone8')
        
        register9 = reg8(name8=name8, email8=email8, phone8=phone8,date=datetime.today())
        register9.save()
    return render(request, 'register5.html')

def register6(request):
    if request.method == "POST":
        name9 = request.POST.get('name9')
        email9 = request.POST.get('email9')
        phone9 = request.POST.get('phone9')
        
        register10 = reg9(name9=name9, email9=email9, phone9=phone9,date=datetime.today())
        register10.save()
    return render(request, 'register6.html')