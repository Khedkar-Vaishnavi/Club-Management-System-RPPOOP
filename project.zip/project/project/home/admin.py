from django.contrib import admin
from home.models import reg
from home.models import reg1
from home.models import reg2
from home.models import reg3
from home.models import reg4
from home.models import reg5
from home.models import reg6
from home.models import reg7
from home.models import reg8
from home.models import reg9

# Register your models here.
admin.site.register(reg)
admin.site.register(reg1)
admin.site.register(reg2)
admin.site.register(reg3)
admin.site.register(reg4)
admin.site.register(reg5)
admin.site.register(reg6)
admin.site.register(reg7)
admin.site.register(reg8)
admin.site.register(reg9)